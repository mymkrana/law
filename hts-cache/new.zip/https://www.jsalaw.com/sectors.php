
<!--Include Functions-->
<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">	<title>Our Sectors | JSA Law</title>
	<!--Default.css-->
<link rel="stylesheet" href="https://www.jsalaw.com/css/navbar.css">
<!--Bootstrap-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/css/bootstrap.min.css">
<!--Font Awesome-->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.9/css/all.css">
<!--Animate.css-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@3.5.2/animate.min.css">
<!--Default.css-->
<link rel="stylesheet" href="https://www.jsalaw.com/css/default.css">
<!--Jquery UI-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
<!--Scroll Animate-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.3/aos.css" />
<!--Serif Font-->
<link href='https://fonts.googleapis.com/css?family=Playfair Display' rel='stylesheet'>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131392439-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131392439-1');
</script>


	<!--jQuery-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<!--Popper-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<!--Bootstrap-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/js/bootstrap.min.js"></script>
<!--jQuery UI-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<!--Scroll Reveal-->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.3/aos.js"></script>
 <script>
	 $(document).ready(function(){
		AOS.init({
			duration: 700, // values from 0 to 3000, with step 50ms
			once: true, 
		}); 
	 });
	 /* lazyload.js (c) Lorenzo Giuliani
 * MIT License (http://www.opensource.org/licenses/mit-license.html)
 *
 * expects a list of:  
 * `<img src="blank.gif" data-src="my_image.png" width="600" height="400" class="lazy">`
 */

!function(window){
  var $q = function(q, res){
        if (document.querySelectorAll) {
          res = document.querySelectorAll(q);
        } else {
          var d=document
            , a=d.styleSheets[0] || d.createStyleSheet();
          a.addRule(q,'f:b');
          for(var l=d.all,b=0,c=[],f=l.length;b<f;b++)
            l[b].currentStyle.f && c.push(l[b]);

          a.removeRule(0);
          res = c;
        }
        return res;
      }
    , addEventListener = function(evt, fn){
        window.addEventListener
          ? this.addEventListener(evt, fn, false)
          : (window.attachEvent)
            ? this.attachEvent('on' + evt, fn)
            : this['on' + evt] = fn;
      }
    , _has = function(obj, key) {
        return Object.prototype.hasOwnProperty.call(obj, key);
      }
    ;

  function loadImage (el, fn) {
    var img = new Image()
      , src = el.getAttribute('data-src');
    img.onload = function() {
      if (!! el.parent)
        el.parent.replaceChild(img, el)
      else
        el.src = src;

      fn? fn() : null;
    }
    img.src = src;
  }

  function elementInViewport(el) {
    var rect = el.getBoundingClientRect()

    return (
       rect.top    >= 0
    && rect.left   >= 0
    && rect.top <= (window.innerHeight || document.documentElement.clientHeight)
    )
  }

    var images = new Array()
      , query = $q('img.lazy')
      , processScroll = function(){
          for (var i = 0; i < images.length; i++) {
            if (elementInViewport(images[i])) {
              loadImage(images[i], function () {
                images.splice(i, i);
              });
            }
          };
        }
      ;
    // Array.prototype.slice.call is not callable under our lovely IE8 
    for (var i = 0; i < query.length; i++) {
      images.push(query[i]);
    };

    processScroll();
    addEventListener('scroll',processScroll);

}(this);
</script></head>

<body>
	<style>
		h4 {
			margin-top: 1.25rem !important;
		}
	</style>
	<!--Navbar-->
	<div class="container-fluid sticky-top bg-white border-bottom d-none d-lg-block">
	<nav class="navbar navbar-expand-lg navbar-light pt-2 pb-0">
		<a class="navbar-brand pt-0 pb-0" href="https://www.jsalaw.com"> 
			 <img src="https://www.jsalaw.com/img/jsa-logos/jsa-logo-navbar.png" height="70" alt="">
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse collapse-desktop navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav ml-auto font-weight-bold">
				<a class="nav-link nav-link-desktop px-3 pb-4 mt-4 hvr-underline-from-center" data-toggle="collapse" data-target="#the_firm" data-parent="#myGroup">
					THE FIRM<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<a class="nav-link nav-link-desktop px-3 pb-4 mt-4 hvr-underline-from-center" data-toggle="collapse" data-target="#our_expertise" data-parent="#myGroup">
					OUR EXPERTISE<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<a class="nav-link nav-link-desktop px-3 pb-4 mt-4 hvr-underline-from-center" data-toggle="collapse" data-target="#our_people" data-parent="#myGroup">
					OUR PEOPLE<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<a class="nav-link nav-link-desktop px-3 pb-4 mt-4 hvr-underline-from-center" data-toggle="collapse" data-target="#locations_website" data-parent="#myGroup">
					OUR LOCATIONS<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<a class="nav-link nav-link-desktop px-3 pb-4 mt-4 hvr-underline-from-center" href="https://www.jsalaw.com">
					<i class="fas fa-home"></i>
				</a>
				<a  id="home_header" class="nav-link nav-link-desktop px-3 pb-4 mt-4 hvr-underline-from-center" data-toggle="collapse" data-target="#search_website" data-parent="#myGroup">
					<i class="fas fa-search"></i>
				</a>
			</ul>
		</div>
	</nav>
</div>

<div id="the_firm" class="row w-100 m-0 collapse collapse-desktop bg-light-2 require-padding position-fixed">
	<div class="col-md-10 offset-md-1 text-center">
		<div class="row w-100 m-0">
			<div class="col-md-4">
				<a href="/firm-profile" style="color:#333;" class="hvr-underline-reveal">FIRM PROFILE</a>
			</div>
			<div class="col-md-4">
				<a href="/our-network" style="color:#333;" class="hvr-underline-reveal">OUR NETWORK</a>
			</div>
			<div class="col-md-4">
				<a href="/life-at-jsa" style="color:#333;" class="hvr-underline-reveal">LIFE AT JSA</a>
			</div>
		</div>
	</div>
</div>
<div id="our_expertise" class="row w-100 m-0 collapse collapse-desktop bg-light-2 no-padding position-fixed">
	<div class="col-md-10 offset-md-1 text-left">
		<div class="row w-100 m-0 py-4">
			<div class="col-md-4">
				<h5>PRACTICE AREAS</h5>
				<div class="row">
										<div class="col-md-12 my-1">
							<a href="/practice-area/corporate">Corporate</a>
						</div>
										<div class="col-md-12 my-1">
							<a href="/practice-area/disputes">Disputes</a>
						</div>
										<div class="col-md-12 my-1">
							<a href="/practice-area/banking-and-finance">Finance</a>
						</div>
								</div>
			</div>
			<div class="col-md-8">
				<a href="/sectors"><h5 style="color: #000;">SECTORS</h5></a>
				<div class="row">
										<div class="col-md-6 my-1">
							<a href="/sectors/agriculture">Agriculture</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/automotive">Automotive</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/aviation">Aviation</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/defence">Defence</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/education">Education</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/hospitality">Hospitality</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/knowledge-based-industries">Knowledge Based Industries</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/logistics-and-allied-industries">Logistics & Allied Industries</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/manufacturing-and-consumer-products">Manufacturing & Consumer Products</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/media-and-sports">Media and Sports</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/oil-and-gas">Oil & Gas</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/pharma">Pharma</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/ports">Ports</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/real-estate">Real Estate</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/renewable-and-cleantech">Renewable & Cleantech</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/retail">Retail</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/smart-cities">Smart Cities</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/startups">Startups</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/telecommunications">Telecommunications</a>
						</div>
										<div class="col-md-6 my-1">
							<a href="/sectors/transport">Transport</a>
						</div>
								</div>
			</div>
		</div>
	</div>
</div>
<div id="our_people" class="row w-100 m-0 collapse collapse-desktop bg-light-2  require-padding position-fixed">
	<div class="col-md-10 offset-md-1 text-center">
		<div class="row w-100 m-0">
			<div class="col-md-4">
				<a href="/join-us" style="color:#333;" class="hvr-underline-reveal">JOIN US</a>
			</div>
			<div class="col-md-4">
				<a href="/our-people" style="color:#333;" class="hvr-underline-reveal">ATTORNEYS</a>
			</div>
			<div class="col-md-4">
				<a href="/alumni" style="color:#333;" class="hvr-underline-reveal">ALUMNI</a>
			</div>
		</div>
	</div>
</div>
<div id="search_website" class="row w-100 m-0 collapse collapse-desktop bg-light-2 position-fixed">
	<div class="col-md-10 offset-md-1 text-center">
		<div class="row w-100 m-0">
			<div class="col-md-10 offset-md-1 py-4">
				<form method="get" action="/search.php">	
					<div class="input-group mb-3">
						<input type="text" class="form-control py-2 border-danger border-right-0" id="lawyer_name" name="search_term" placeholder="Try 'Disputes'" aria-describedby="basic-addon2">
						<button type="submit" class="input-group-append input-group-text py-2 border-danger border-left-0" id="basic-addon2"><i class="fas fa-search"></i></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<div id="locations_website" class="row w-100 m-0 collapse collapse-desktop bg-light-2  position-fixed py-3">
	<div class="col-md10 offset-md-1">
		<div class="row w-100 m-0">
						<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/ahmedabad">
							AHMEDABAD						</a>
						<a href="https://goo.gl/maps/13TuvrqCpD12" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 7966111061" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#7e1f16131b1a1f1c1f1a3e140d1f121f09501d1113" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="7c1d141119181d1e1d183c160f1d101d0b521f1311">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/bengaluru">
							BENGALURU						</a>
						<a href="https://goo.gl/maps/GULFKQoHtvz" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 8043503600" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#8ae8efe4edebe6fff8ffcae0f9ebe6ebfda4e9e5e7" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="b0d2d5ded7d1dcc5c2c5f0dac3d1dcd1c79ed3dfdd">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/chennai">
							CHENNAI						</a>
						<a href="https://goo.gl/maps/eUwg7Lm3VVr" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 4449306600" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#ee8d868b80808f87ae849d8f828f99c08d8183" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="7d1e151813131c143d170e1c111c0a531e1210">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/gift-ifsc">
							GIFT IFSC						</a>
						<a href="https://goo.gl/maps/m33GWo85P6L2" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 9004091936" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#680f010e1c010e1b0b28021b0904091f460b0705" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="f09799968499968393b09a83919c9187de939f9d">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/gurugram">
							GURUGRAM						</a>
						<a href="https://goo.gl/maps/5nzEr2HHfRy" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 1244390600" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#adcad8dfd8cadfccc0edc7deccc1ccda83cec2c0" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="056270777062776468456f76646964722b666a68">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/hyderabad">
							HYDERABAD						</a>
						<a href="https://goo.gl/maps/GvyHFUj6dqD2" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 4023635600" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#f890819c9d8a999a999cb8928b9994998fd69b9795" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="026a7b66677063606366426871636e63752c616d6f">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/mumbai">
							MUMBAI						</a>
						<a href="https://goo.gl/maps/uaBXMTrseyF2" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title="+91 2243418600" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#9ff2eaf2fdfef6dff5ecfef3fee8b1fcf0f2" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="7419011916151d341e07151815035a171b19">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-dark font-weight-bold" href="/locations/new-delhi">
							NEW DELHI						</a>
						<a href="https://goo.gl/maps/pMvyJ8X5yq52" target="_blank" class="float-right">
							<i class="fa fa-map-marker-alt text-danger" ></i>
						</a>
						<a class="phone-icon-lg" data-toggle="tooltip" title=" +91 1143110600" style="float: right;padding-right: 10px;">
							<i class="fa fa-phone text-danger" ></i>
						</a>
					</div>
				</div>
				<a href="/cdn-cgi/l/email-protection#96f8f3e1f2f3fafeffd6fce5f7faf7e1b8f5f9fb" class="text-dark">
					<i class="fa fa-envelope text-danger mt-2"></i>&nbsp;<span class="__cf_email__" data-cfemail="543a31233031383c3d143e27353835237a373b39">[email&#160;protected]</span>				</a>
			</div>
				<div class="col-md-4 py-2 px-5  bg-light-2">
				<div class="row">
					<div class="col-md-12">
						<a class="text-danger font-weight-bold float-left mt-2" href="/locations">
							All Locations
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
</div>

<!--Mobile Navbar-->
<div class="container-fluid sticky-top bg-white border-bottom d-lg-none text-center" style="z-index: 100;">
	<nav class="navbar navbar-expand-lg navbar-light pt-2 pb-0">
		<a class="navbar-brand pt-0 pb-0" href="https://www.jsalaw.com"> 
			 <img src="https://www.jsalaw.com/img/jsa-logos/jsa-logo-navbar.png" height="70" alt="">
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent_mobile" aria-controls="navbarSupportedContent_mobile" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse collapse-mobile navbar-collapse" id="navbarSupportedContent_mobile">
			<ul class="navbar-nav ml-auto font-weight-bold">
				<a class="nav-link nav-link-mobile px-3 my-2" data-toggle="collapse" data-target="#the_firm_mobile" href="#the_firm_mobile">
					THE FIRM<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<div id="the_firm_mobile" class="row w-100 m-0 collapse collapse-mobile bg-light-2">
					<div class="row w-100 m-0">
						<div class="col-4 py-3">
							<a href="/firm-profile">Firm Profile</a>
						</div>
						<div class="col-4 py-3">
							<a href="/our-network">Our Network</a>
						</div>
						<div class="col-4 py-3">
							<a href="/life-at-jsa">Life At JSA</a>
						</div>
					</div>
				</div>
				<a class="nav-link nav-link-mobile px-3 my-2" data-toggle="collapse" data-target="#our_expertise_mobile" href="#our_expertise_mobile">
					OUR EXPERTISE<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<div id="our_expertise_mobile" class="row w-100 m-0 collapse collapse-mobile bg-light-2 ">
					<div class="col-md-10 offset-md-1">
						<div class="row w-100 m-0 py-4">
							<div class="col-md-4">
								<p class="font-weight-bold">PRACTICE AREAS</p>
								<div class="row">
																		<div class="col-4 pb-4">
											<a href="/practice-area/corporate">Corporate</a>
										</div>
																		<div class="col-4 pb-4">
											<a href="/practice-area/disputes">Disputes</a>
										</div>
																		<div class="col-4 pb-4">
											<a href="/practice-area/banking-and-finance">Finance</a>
										</div>
																</div>
							</div>
							<div class="col-md-8">
								<p  class="font-weight-bold">SECTORS</p>
									<a href="/sectors">View All</a>
							</div>
						</div>
					</div>
				</div>
				<a class="nav-link nav-link-mobile px-3 my-2" data-toggle="collapse" data-target="#our_people_mobile" href="#our_people_mobile">
					OUR PEOPLE<i class="fas fa-chevron-down ml-2"></i>
				</a>
				<div id="our_people_mobile" class="row w-100 m-0 collapse collapse-mobile bg-light-2 ">
					<div class="row w-100 m-0">
						<div class="col-4 py-2">
							<a href="/join-us">Join Us</a>
						</div>
						<div class="col-4 py-2">
							<a href="/our-people">Attorneys</a>
						</div>
						<div class="col-4 py-2">
							<a href="/alumni">Alumni</a>
						</div>
					</div>
				</div>
				<a class="nav-link nav-link-mobile px-3 my-2" href="/locations">
					OUR LOCATIONS</i>
				</a>
				<div class="nav-link nav-link-mobile my-2">
					<form method="get" action="/search.php">	
						<div class="input-group mb-3">
							<input type="text" class="form-control py-2 border-danger border-right-0" id="lawyer_name_mobile" name="search_term" placeholder="Try 'Disputes'" aria-describedby="basic-addon2">
							<button type="submit" class="input-group-append input-group-text py-2 border-danger border-left-0" id="basic-addon2"><i class="fas fa-search"></i></button>
						</div>
					</form>
				</div>
			</ul>
		</div>
	</nav>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
	$('.nav-link-desktop').click( function(e) {
		$('.collapse-desktop').collapse('hide');
	});

	$(function() {
		
		
		var projects = [  
		{ slug: 'aarthi-sivanandh',page_name: 'lawyers',value: 'Aarthi Sivanandh'},{ slug: 'aashit-shah',page_name: 'lawyers',value: 'Aashit Shah'},{ slug: 'amar-gupta',page_name: 'lawyers',value: 'Amar Gupta'},{ slug: 'amit-kapur',page_name: 'lawyers',value: 'Amit Kapur'},{ slug: 'amitabh-kumar',page_name: 'lawyers',value: 'Amitabh Kumar'},{ slug: 'anupam-varma',page_name: 'lawyers',value: 'Anupam Varma'},{ slug: 'bijal-chhatrapati',page_name: 'lawyers',value: 'Bijal Chhatrapati'},{ slug: 'dina-wadia',page_name: 'lawyers',value: 'Dina Wadia'},{ slug: 'divyanshu-pandey',page_name: 'lawyers',value: 'Divyanshu Pandey'},{ slug: 'farhad-sorabjee',page_name: 'lawyers',value: 'Farhad Sorabjee'},{ slug: 'gerald-manoharan',page_name: 'lawyers',value: 'Gerald Manoharan'},{ slug: 'manvinder-singh',page_name: 'lawyers',value: 'Manvinder Singh'},{ slug: 'poonam-verma',page_name: 'lawyers',value: 'Poonam Verma'},{ slug: 'rohitashwa-prasad',page_name: 'lawyers',value: 'Rohitashwa Prasad'},{ slug: 'rupindar-malik',page_name: 'lawyers',value: 'Rupinder Malik'},{ slug: 'sajai-singh',page_name: 'lawyers',value: 'Sajai Singh'},{ slug: 'sandeep-mehta',page_name: 'lawyers',value: 'Sandeep Mehta'},{ slug: 'shivpriya-nanda',page_name: 'lawyers',value: 'Shivpriya Nanda'},{ slug: 'trisheet-chatterjee',page_name: 'lawyers',value: 'Trisheet Chatterjee'},{ slug: 'upendra-nath-sharma',page_name: 'lawyers',value: 'Upendra Nath Sharma'},{ slug: 'venkatesh-raman-prasad',page_name: 'lawyers',value: 'Venkatesh Raman Prasad'},{ slug: 'vikram-raghani',page_name: 'lawyers',value: 'Vikram Raghani'},{ slug: 'vinod-kumar',page_name: 'lawyers',value: 'Vinod Kumar'},{ slug: 'vivek-k-chandy',page_name: 'lawyers',value: 'Vivek K. Chandy'},{ slug: 'bharat-bhushan-sharma',page_name: 'lawyers',value: 'Bharat Bhushan Sharma'},{ slug: 'bharati-joshi',page_name: 'lawyers',value: 'Bharati Joshi'},{ slug: 'bhavana-elizabeth-alexander',page_name: 'lawyers',value: 'Bhavana Elizabeth Alexander'},{ slug: 'bir-bahadur-singh-sachar',page_name: 'lawyers',value: 'Bir Bahadur Singh Sachar'},{ slug: 'herur-rajesh-kumar',page_name: 'lawyers',value: 'Herur Rajesh Kumar'},{ slug: 'kunal-kaul',page_name: 'lawyers',value: 'Kunal Kaul'},{ slug: 'manuel-jose',page_name: 'lawyers',value: 'Manuel Jose'},{ slug: 'nikhil-sharma',page_name: 'lawyers',value: 'Nikhil Sharma'},{ slug: 'prakriti-jaiswal',page_name: 'lawyers',value: 'Prakriti Jaiswal'},{ slug: 'purnachandra-rao-tadepalli',page_name: 'lawyers',value: 'Purnachandra Rao Tadepalli'},{ slug: 'rajat-joneja',page_name: 'lawyers',value: 'Rajat Joneja'},{ slug: 'rajul-bohra',page_name: 'lawyers',value: 'Rajul Bohra'},{ slug: 'revathy-muralidharan',page_name: 'lawyers',value: 'Revathy Muralidharan'},{ slug: 'ronak-ajmera',page_name: 'lawyers',value: 'Ronak Ajmera'},{ slug: 'sahil-shah',page_name: 'lawyers',value: 'Sahil Shah'},{ slug: 'shantanu-jindel',page_name: 'lawyers',value: 'Shantanu Jindel'},{ slug: 'siddharth-k-vedula',page_name: 'lawyers',value: 'Siddharth K. Vedula'},{ slug: 'vishnu-nair',page_name: 'lawyers',value: 'Vishnu Nair'},{ slug: 'zain-pandit',page_name: 'lawyers',value: 'Zain Pandit'},{ slug: 'abhishek-munot',page_name: 'lawyers',value: 'Abhishek Munot'},{ slug: 'aditya-rathi',page_name: 'lawyers',value: 'Aditya Rathi'},{ slug: 'anand-lakra',page_name: 'lawyers',value: 'Anand Lakra'},{ slug: 'ananya-kumar',page_name: 'lawyers',value: 'Ananya Kumar'},{ slug: 'anish-mashruwala',page_name: 'lawyers',value: 'Anish Mashruwala'},{ slug: 'anjana-j-potti',page_name: 'lawyers',value: 'Anjana J. Potti'},{ slug: 'archana-panchal',page_name: 'lawyers',value: 'Archana Panchal'},{ slug: 'archana-tewary',page_name: 'lawyers',value: 'Archana Tewary'},{ slug: 'arjun-k-perikal',page_name: 'lawyers',value: 'Arjun K. Perikal'},{ slug: 'arka-mookerjee',page_name: 'lawyers',value: 'Arka Mookerjee'},{ slug: 'abhilash-chandran',page_name: 'lawyers',value: 'Abhilash Chandran'},{ slug: 'ashish-suman',page_name: 'lawyers',value: 'Ashish Suman'},{ slug: 'abhishek-kumar-singh',page_name: 'lawyers',value: 'Abhishek Kumar Singh'},{ slug: 'abraham-vishal-jacob',page_name: 'lawyers',value: 'Abraham Vishal Jacob'},{ slug: 'adil-ladha',page_name: 'lawyers',value: 'Adil Ladha'},{ slug: 'aditi-v-deshpande',page_name: 'lawyers',value: 'Aditi V Deshpande'},{ slug: 'divyam-agarwal',page_name: 'lawyers',value: 'Divyam Agarwal'},{ slug: 'hormuz-d-mehta',page_name: 'lawyers',value: 'Hormuz D. Mehta'},{ slug: 'jamshed-bhumgara',page_name: 'lawyers',value: 'Jamshed Bhumgara'},{ slug: 'kartik-jain',page_name: 'lawyers',value: 'Kartik Jain'},{ slug: 'kavita-patwardhan',page_name: 'lawyers',value: 'Kavita Patwardhan'},{ slug: 'kumarmangalam-vijay',page_name: 'lawyers',value: 'Kumarmanglam Vijay'},{ slug: 'malini-raju',page_name: 'lawyers',value: 'Malini Raju'},{ slug: 'manav-raheja',page_name: 'lawyers',value: 'Manav Raheja'},{ slug: 'mary-julie-john',page_name: 'lawyers',value: 'Mary Julie John'},{ slug: 'mayank-mishra',page_name: 'lawyers',value: 'Mayank Mishra'},{ slug: 'megha-arora',page_name: 'lawyers',value: 'Megha Arora'},{ slug: 'minu-dwivedi',page_name: 'lawyers',value: 'Minu Dwivedi'},{ slug: 'mohit-makshi',page_name: 'lawyers',value: 'Mohit Bakshi'},{ slug: 'nosh-modi',page_name: 'lawyers',value: 'Nosh Modi'},{ slug: 'ongmu-tshering',page_name: 'lawyers',value: 'Ongmu Tshering'},{ slug: 'pallavi-puri',page_name: 'lawyers',value: 'Pallavi Puri'},{ slug: 'prasanth-vg',page_name: 'lawyers',value: 'Prasanth V.G.'},{ slug: 'pratik-pawar',page_name: 'lawyers',value: 'Pratik Pawar'},{ slug: 'probir-roy-chowdhury',page_name: 'lawyers',value: 'Probir Roy Chowdhury'},{ slug: 'raj-ramachandran',page_name: 'lawyers',value: 'Raj Ramachandran'},{ slug: 'rajesh-g-pal',page_name: 'lawyers',value: 'Rajesh G. Pal'},{ slug: 'reeti-choudhary',page_name: 'lawyers',value: 'Reeti Choudhary'},{ slug: 'rinku-ambedkar',page_name: 'lawyers',value: 'Rinku Ambekar'},{ slug: 'sanjay-kishore',page_name: 'lawyers',value: 'Sanjay Kishore'},{ slug: 'shailesh-shukla',page_name: 'lawyers',value: 'Shailesh Shukla'},{ slug: 'sidharth-sethi',page_name: 'lawyers',value: 'Sidharth Sethi'},{ slug: 'soumitra-majumdar',page_name: 'lawyers',value: 'Soumitra Majumdar'},{ slug: 'sujoy-bhatia',page_name: 'lawyers',value: 'Sujoy Bhatia'},{ slug: 'swetha-prashant',page_name: 'lawyers',value: 'Swetha Prashant'},{ slug: 'tirthankar-datta',page_name: 'lawyers',value: 'Tirthankar Datta'},{ slug: 'tony-verghese',page_name: 'lawyers',value: 'Tony Verghese'},{ slug: 'utsav-johri',page_name: 'lawyers',value: 'Utsav Johri'},{ slug: 'uttara-m-kolhatkar',page_name: 'lawyers',value: 'Uttara M. Kolhatkar'},{ slug: 'vaibhav-choukse',page_name: 'lawyers',value: 'Vaibhav Choukse'},{ slug: 'vibha-dhawan',page_name: 'lawyers',value: 'Vibha Dhawan'},{ slug: 'vidhyadhare-s',page_name: 'lawyers',value: 'Vidhyadhare S.'},{ slug: 'deepika-bhargava',page_name: 'lawyers',value: 'Deepika Bhargava'},{ slug: 'fatema-kachwalla',page_name: 'lawyers',value: 'Fatema Kachwalla'},{ slug: 'unnati-agarwal',page_name: 'lawyers',value: 'Unnati Agrawal'},{ slug: 'udhav-gulati',page_name: 'lawyers',value: 'Udhav Gulati'},{ slug: 'gaurav-g-arora',page_name: 'lawyers',value: 'Gaurav G. Arora'},{ slug: 'janmali-gr-manikala',page_name: 'lawyers',value: 'Janmali G.R. Manikala'},{ slug: 'suneethi-hs',page_name: 'lawyers',value: 'Suneethi H.S.'},{ slug: 'sunanda-g',page_name: 'lawyers',value: 'Sunanda G.'},{ slug: 'kartikeya-dar',page_name: 'lawyers',value: 'Kartikeya Dar'},{ slug: 'kartikeya-gajjala',page_name: 'lawyers',value: 'Kartikeya Gajjala'},{ slug: 'kaustubh-verma',page_name: 'lawyers',value: 'Kaustubh Verma'},{ slug: 'sonali-kapoor',page_name: 'lawyers',value: 'Sonali Kapoor'},{ slug: 'sindhu-nayak',page_name: 'lawyers',value: 'Sindhu Nayak'},{ slug: 'shivani-chugh',page_name: 'lawyers',value: 'Shivani Chugh'},{ slug: 'sherill-pal',page_name: 'lawyers',value: 'Sherill Pal'},{ slug: 'shashank-vikram-singh',page_name: 'lawyers',value: 'Shashank Vikram Singh'},{ slug: 'shanaya-cyrus-irani',page_name: 'lawyers',value: 'Shanaya Cyrus Irani'},{ slug: 'ruchi-mehta',page_name: 'lawyers',value: 'Ruchi Mehta'},{ slug: 'mohan-kumar-kalagarla',page_name: 'lawyers',value: 'Mohan Kumar Kalagarla'},{ slug: 'ritika-vaswani',page_name: 'lawyers',value: 'Ritika Vaswani'},{ slug: 'pallavi-banerjee',page_name: 'lawyers',value: 'Pallavi Banerjee'},{ slug: 'rajji-k-partani',page_name: 'lawyers',value: 'Rakki K. Partani'},{ slug: 'rakesh-warrier',page_name: 'lawyers',value: 'Rakesh Warrier'},{ slug: 'pooranimaa-hariharan',page_name: 'lawyers',value: 'Pooranimaa Hariharan'},{ slug: 'rahul-kinra',page_name: 'lawyers',value: 'Rahul Kinra'},{ slug: 'pracheta-bhattacharya',page_name: 'lawyers',value: 'Pracheta Bhattacharya'},{ slug: 'radhika-gupta',page_name: 'lawyers',value: 'Radhika Gupta'},{ slug: 'pragya-chauhan',page_name: 'lawyers',value: 'Pragya Chauhan'},{ slug: 'srikant-cv',page_name: 'lawyers',value: 'Srikant C.V.'},{ slug: 'arpita-garg',page_name: 'lawyers',value: 'Arpita Garg'},{ slug: 'sunjung-kim',page_name: 'lawyers',value: 'Sunjung Kim'},{ slug: 'abhishek-singh',page_name: 'lawyers',value: 'Abhishek Singh'},{ slug: 'abhishek-subbaiah',page_name: 'lawyers',value: 'Abhishek Subbaiah'},{ slug: 'abiha-zaidi',page_name: 'lawyers',value: 'Abiha Zaidi'},{ slug: 'adhiraj-gupta',page_name: 'lawyers',value: 'Adhiraj Gupta'},{ slug: 'akansha-mehta',page_name: 'lawyers',value: 'Akansha Mehta'},{ slug: 'akshay-bhagchandani',page_name: 'lawyers',value: 'Akshay Bhagchandani'},{ slug: 'alvia-ahmed',page_name: 'lawyers',value: 'Alvia Ahmed'},{ slug: 'amandeep-singh-virk',page_name: 'lawyers',value: 'Amandeep Singh Virk'},{ slug: 'ameya-vikram-mishra',page_name: 'lawyers',value: 'Ameya Vikram Mishra'},{ slug: 's-ananth-balaji',page_name: 'lawyers',value: 'S. Ananth Balaji'},{ slug: 'anshu-bansal',page_name: 'lawyers',value: 'Anshu Bansal'},{ slug: 'anup-vijay-kulkarni',page_name: 'lawyers',value: 'Anup Vijay Kulkarni'},{ slug: 'aparajita-upadhyay',page_name: 'lawyers',value: 'Aparajita Upadhyay'},{ slug: 'apoorva-sundar',page_name: 'lawyers',value: 'Apoorva Sundar'},{ slug: 'aratika-nandi',page_name: 'lawyers',value: 'Aratrika Nandi'},{ slug: 'arpita-latta',page_name: 'lawyers',value: 'Arpita Latta'},{ slug: 'arjun-krishnamoorthy',page_name: 'lawyers',value: 'Arjun Krishnamoorthy'},{ slug: 'arvind-parikh',page_name: 'lawyers',value: 'Arvind Parikh'},{ slug: 'ashrafi-ginwalla',page_name: 'lawyers',value: 'Ashrafi Ginwalla'},{ slug: 'ashwin-nayar',page_name: 'lawyers',value: 'Ashwin Nayar'},{ slug: 'astha-srivastava',page_name: 'lawyers',value: 'Astha Srivastava'},{ slug: 'ayisha-mansoor',page_name: 'lawyers',value: 'Ayisha Mansoor'},{ slug: 'ayushi-pandey',page_name: 'lawyers',value: 'Ayushi Pandey'},{ slug: 'bhargavi-ravi',page_name: 'lawyers',value: 'Bhargavi Ravi'},{ slug: 'catherine-ranji-ayallore',page_name: 'lawyers',value: 'Catherine Ranji Ayallore'},{ slug: 'd-divyanshu',page_name: 'lawyers',value: 'D. Divyanshu'},{ slug: 'ela-bali',page_name: 'lawyers',value: 'Ela Bali'},{ slug: 'guneet-singh-chadha',page_name: 'lawyers',value: 'Guneet Singh Chadha'},{ slug: 'hema-priyadarshini-patnaik',page_name: 'lawyers',value: 'Hema Priyadarshini Patnaik'},{ slug: 'kasturi-verma',page_name: 'lawyers',value: 'Kasturi Verma'},{ slug: 'khamir-kamdar',page_name: 'lawyers',value: 'Khamir Kamdar'},{ slug: 'kirti-singh',page_name: 'lawyers',value: 'Kirti Singh'},{ slug: 'krishna-tangirala',page_name: 'lawyers',value: 'Krishna Tangirala'},{ slug: 'kumar-kisley',page_name: 'lawyers',value: 'Kumar Kislay'},{ slug: 'lakshmi-ramchandran',page_name: 'lawyers',value: 'Lakshmi Ramachandran'},{ slug: 'malcolm-desai',page_name: 'lawyers',value: 'Malcolm Desai'},{ slug: 'manini-saraswat',page_name: 'lawyers',value: 'Manini Saraswat'},{ slug: 'medha-shah',page_name: 'lawyers',value: 'Medha Shah'},{ slug: 'meena-b-s',page_name: 'lawyers',value: 'Meena B. S.'},{ slug: 'meenakshy-k-natesan',page_name: 'lawyers',value: 'Meenakshy K. Natesan'},{ slug: 'megha-kapoor',page_name: 'lawyers',value: 'Megha Kapoor'},{ slug: 'neelasha-nemani',page_name: 'lawyers',value: 'Neelasha Nemani'},{ slug: 'parth-jain',page_name: 'lawyers',value: 'Parth Jain'},{ slug: 'pooja-kumari',page_name: 'lawyers',value: 'Pooja Kumari'},{ slug: 'pooja-murty',page_name: 'lawyers',value: 'Pooja Murty'},{ slug: 'pooja-thomas',page_name: 'lawyers',value: 'Pooja Thomas'},{ slug: 'prannoy-shekhar-semwal',page_name: 'lawyers',value: 'Prannoy Shekhar Semwal'},{ slug: 'prashaanth-balasubramaniam',page_name: 'lawyers',value: 'Prashaanth Balasubramaniam'},{ slug: 'priyanka-murali',page_name: 'lawyers',value: 'Priyanka Murali'},{ slug: 'raghav-sabharwal',page_name: 'lawyers',value: 'Raghav Sabharwal'},{ slug: 'raveena-dhameeja',page_name: 'lawyers',value: 'Raveena Dhamija'},{ slug: 'reshma-oak',page_name: 'lawyers',value: 'Reshma Oak'},{ slug: 'rishabh-jain',page_name: 'lawyers',value: 'Rishabh Jain'},{ slug: 'rishabhdev-jain',page_name: 'lawyers',value: 'Rishabhdev Jain'},{ slug: 'zubin-sethna',page_name: 'lawyers',value: 'Zubin Sethna'},{ slug: 'ronak-thakkar',page_name: 'lawyers',value: 'Ronak Thakkar'},{ slug: 'yohaan-kersi-limathwalla',page_name: 'lawyers',value: 'Yohaann Kersi Limathwalla'},{ slug: 'yashaswi-kant',page_name: 'lawyers',value: 'Yashaswi Kant'},{ slug: 'santosh-shah',page_name: 'lawyers',value: 'Santosh Shah'},{ slug: 'yajas-setlur',page_name: 'lawyers',value: 'Yajas Setlur'},{ slug: 'saumay-bhasin',page_name: 'lawyers',value: 'Saumay Bhasin'},{ slug: 'vishal-shah',page_name: 'lawyers',value: 'Vishal Shah'},{ slug: 'shrijita-bhattacharya',page_name: 'lawyers',value: 'Shrijita Bhattacharya'},{ slug: 'vedashree-p-ravishanker',page_name: 'lawyers',value: 'Vedashree P. Ravishankar'},{ slug: 'shweta-gupta',page_name: 'lawyers',value: 'Shweta Gupta'},{ slug: 'vandana-anand',page_name: 'lawyers',value: 'Vandana Anand'},{ slug: 'tushar-nagar',page_name: 'lawyers',value: 'Tushar Nagar'},{ slug: 'siddharth-sinha',page_name: 'lawyers',value: 'Siddharth Sinha'},{ slug: 'siddhesh-s-pradhan',page_name: 'lawyers',value: 'Siddhesh S. Pradhan'},{ slug: 'sindhuja-satti',page_name: 'lawyers',value: 'Sindhuja Satti'},{ slug: 'tanisha-bhatia',page_name: 'lawyers',value: 'Tanisha Bhatia'},{ slug: 'sonakshi-das',page_name: 'lawyers',value: 'Sonakshi Das'},{ slug: 'sweta-singh',page_name: 'lawyers',value: 'Sweta Singh'},{ slug: 'stuti-shah',page_name: 'lawyers',value: 'Stuti Shah'},{ slug: 'srinivasan-m-d',page_name: 'lawyers',value: 'Srinivasan M.D.'},{ slug: 'srishti-moitra',page_name: 'lawyers',value: 'Srishti Moitra'},{ slug: 'jyoti-sagar',page_name: 'lawyers',value: 'Jyoti Sagar'},{ slug: 'vishnu-p-sudarsan',page_name: 'lawyers',value: 'Vishnu P. Sudarsan'},{ slug: 'dhirendra-negi',page_name: 'lawyers',value: 'Dhirendra Negi'},{ slug: 'siddharth-tandon',page_name: 'lawyers',value: 'Siddharth Tandon'},{ slug: 'tanvi-trivedi',page_name: 'lawyers',value: 'Tanvi Trivedi'},{ slug: 'samikrith-rao-puskuri',page_name: 'lawyers',value: 'Samikrith Rao Puskuri'},{ slug: 'hemangini-srinidhi',page_name: 'lawyers',value: 'Hemangini Srinidhi'},{ slug: 'tabish-samdani',page_name: 'lawyers',value: 'Tabish Samdani'},{ slug: 'priyal-somvanshi',page_name: 'lawyers',value: 'Priyal Somvanshi'},{ slug: 'vishrov-mukerjee',page_name: 'lawyers',value: 'Vishrov Mukerjee'},{ slug: 't-g-rajesh-kumar',page_name: 'lawyers',value: 'T.G. Rajesh Kumar'},{ slug: 'poongkhulali-balasubramanian',page_name: 'lawyers',value: 'Poongkhulali Balasubramanian'},{ slug: 'manish-kumar-jha',page_name: 'lawyers',value: 'Manish Kumar Jha'},{ slug: 'saeeda-bandukwala',page_name: 'lawyers',value: 'Saeeda Bandukwala'},{ slug: 'lalit-kumar',page_name: 'lawyers',value: 'Lalit Kumar'},{ slug: 'aman-bhatia',page_name: 'lawyers',value: 'Aman Bhatia'},{ slug: 'nitin-potdar',page_name: 'lawyers',value: 'Nitin Potdar'},{ slug: 'dheeraj-nair',page_name: 'lawyers',value: 'Dheeraj Nair'},{ slug: 'varghese-thomas',page_name: 'lawyers',value: 'Varghese Thomas'},{ slug: 's-p-purwar',page_name: 'lawyers',value: 'S P Purwar'},{ slug: 'k-z-kuriyan',page_name: 'lawyers',value: 'K. Z. Kuriyan'},{ slug: 'akshat-jain',page_name: 'lawyers',value: 'Akshat Jain'},{ slug: 'akshatha-s-mattamari',page_name: 'lawyers',value: 'Akshatha S. Mattamari'},{ slug: 'arjun-david-alexander',page_name: 'lawyers',value: 'Arjun David Alexander'},{ slug: 'arshia-saraf',page_name: 'lawyers',value: 'Arshia Saraf'},{ slug: 'abhishek-pundir',page_name: 'lawyers',value: 'Abhishek Singh Pundir'},{ slug: 'bahraiz-f-irani',page_name: 'lawyers',value: 'Bahraiz F. Irani'},{ slug: 'divyam-sharma',page_name: 'lawyers',value: 'Divyam Sharma'},{ slug: 'gayatri-sagar-chopra',page_name: 'lawyers',value: 'Gayatri Sagar Chopra'},{ slug: 'girik-bhalla',page_name: 'lawyers',value: 'Girik Bhalla'},{ slug: 'karan-topiwala',page_name: 'lawyers',value: 'Karan Topiwala'},{ slug: 'pallavi-kumar',page_name: 'lawyers',value: 'Pallavi Kumar'},{ slug: 'parshva-doshi',page_name: 'lawyers',value: 'Parshva Doshi'},{ slug: 'pavithra-manivannan',page_name: 'lawyers',value: 'Pavithra Manivannan'},{ slug: 'sanjna-vijh',page_name: 'lawyers',value: 'Sanjna Vijh'},{ slug: 'shradha-sharma',page_name: 'lawyers',value: 'Shradha Sharma'},{ slug: 'shruti-dass',page_name: 'lawyers',value: 'Shruti Dass'},{ slug: 'simranjeet-singh',page_name: 'lawyers',value: 'Simranjeet Singh'},{ slug: 'sriram-sl',page_name: 'lawyers',value: 'Sriram SL'},{ slug: 'urmika-agarwal',page_name: 'lawyers',value: 'Urmika Agarwal'},{ slug: 'vandana-venkatesh',page_name: 'lawyers',value: 'Vandana Venkatesh'},{ slug: 'farid-karachiwala',page_name: 'lawyers',value: 'Farid Karachiwala'},{ slug: 'farhana-malik',page_name: 'lawyers',value: 'Farhana Malik'},{ slug: 'megha-saraf',page_name: 'lawyers',value: 'Megha Saraf'},{ slug: 'sarvesh-kumar-saluja',page_name: 'lawyers',value: 'Sarvesh Kumar Saluja'},{ slug: 'daksh-ahluwalia',page_name: 'lawyers',value: 'Daksh Ahluwalia'},{ slug: 'aashni-dalal',page_name: 'lawyers',value: 'Aashni Dalal'},{ slug: 'avinash-poojari',page_name: 'lawyers',value: 'Avinash Poojari'},{ slug: 'sakshi.raut',page_name: 'lawyers',value: 'Sakshi Raut'},{ slug: 'swapneil-b-akut',page_name: 'lawyers',value: 'Swapneil B. Akut'},{ slug: 'abhishek-sarkar',page_name: 'lawyers',value: 'Abhishek Sarkar'},{ slug: 'aishwarya-singh',page_name: 'lawyers',value: 'Aishwarya Singh'},{ slug: 'aditya-gupta-2',page_name: 'lawyers',value: 'Aditya Gupta'},{ slug: 'krupa-brahmbhatt',page_name: 'lawyers',value: 'Krupa Brahmbhatt'},{ slug: 'devika-vasandani',page_name: 'lawyers',value: 'Devika Vasandani'},{ slug: 'sourav-modi',page_name: 'lawyers',value: 'Sourav Modi'},{ slug: 'aditya-gupta',page_name: 'lawyers',value: 'Aditya Gupta'},{ slug: 'mahek-chheda',page_name: 'lawyers',value: 'Mahek Chheda'},{ slug: 'sneh-parikh',page_name: 'lawyers',value: 'Sneh Parikh'},{ slug: 'sampurna-nayak',page_name: 'lawyers',value: 'Sampurna Nayak'},{ slug: 'harsheen-madan',page_name: 'lawyers',value: 'Harsheen Madan'},{ slug: 'aditi-sehgal',page_name: 'lawyers',value: 'Aditi Sehgal'},{ slug: 'abhinav-srivastava',page_name: 'lawyers',value: 'Abhinav Srivastava'},{ slug: 'ami-shah',page_name: 'lawyers',value: 'Ami Shah'},{ slug: 'Aishwarya-Abhijit',page_name: 'lawyers',value: 'Aishwarya Abhijit'},{ slug: 'Akshit-Goyal',page_name: 'lawyers',value: 'Akshit Goyal'},{ slug: 'Nakul-Sonejee',page_name: 'lawyers',value: 'Nakul Sonejee'},{ slug: 'Saibarath-S',page_name: 'lawyers',value: 'Saibarath S'},{ slug: 'hemangi-abhyankar',page_name: 'lawyers',value: 'Hemangi Abhyankar'},{ slug: 'arti-raghavan',page_name: 'lawyers',value: 'Arti Raghavan'},{ slug: 'abhishek-iyer',page_name: 'lawyers',value: 'Abhishek Iyer'},{ slug: 'sidharrth-shankar',page_name: 'lawyers',value: 'Sidharrth Shankar'},{ slug: 'tanya-tiwari',page_name: 'lawyers',value: 'Tanya Tiwari'},{ slug: 'zenia-cassinath',page_name: 'lawyers',value: 'Zenia Cassinath '},{ slug: 'sanjana-rao',page_name: 'lawyers',value: 'Sanjana Rao'},{ slug: 'karun-pahwa',page_name: 'lawyers',value: 'Karun Pahwa'},{ slug: 'tarun-singhvi',page_name: 'lawyers',value: 'Tarun Singhvi'},{ slug: 'ragini-rastogi',page_name: 'lawyers',value: 'Ragini Rastogi'},{ slug: 'ashish-joshi',page_name: 'lawyers',value: 'Ashish Joshi'},{ slug: 'prerna-ranjan',page_name: 'lawyers',value: 'Prerna Ranjan'},{ slug: 'shantanu-parashar',page_name: 'lawyers',value: 'Shantanu Parashar'},{ slug: 'maneesh-upadhyay',page_name: 'lawyers',value: 'Maneesh Upadhyay'},{ slug: 'kavya-thayil',page_name: 'lawyers',value: 'Kavya Katherine Thayil'},{ slug: 'krishna-visvanathan',page_name: 'lawyers',value: 'Krishna Visvanathan'},{ slug: 'anant-mishra',page_name: 'lawyers',value: 'Anant Mishra'},{ slug: 'ayushi-singh',page_name: 'lawyers',value: 'Ayushi Singh'},{ slug: 'atul-madhavan',page_name: 'lawyers',value: 'Atul Madhavan'},{ slug: 'angira-lodha',page_name: 'lawyers',value: 'Angira Singhvi Lodha'},{ slug: 'aarti-iyer',page_name: 'lawyers',value: 'Aarti Iyer'},{ slug: 'asim_abbas',page_name: 'lawyers',value: 'Asim Abbas'},{ slug: 'agriculture',page_name: 'sectors',value: 'Agriculture'},{ slug: 'automotive',page_name: 'sectors',value: 'Automotive'},{ slug: 'aviation',page_name: 'sectors',value: 'Aviation'},{ slug: 'defence',page_name: 'sectors',value: 'Defence'},{ slug: 'education',page_name: 'sectors',value: 'Education'},{ slug: 'hospitality',page_name: 'sectors',value: 'Hospitality'},{ slug: 'knowledge-based-industries',page_name: 'sectors',value: 'Knowledge Based Industries'},{ slug: 'telecommunications',page_name: 'sectors',value: 'Telecommunications'},{ slug: 'manufacturing-and-consumer-products',page_name: 'sectors',value: 'Manufacturing & Consumer Products'},{ slug: 'media-and-sports',page_name: 'sectors',value: 'Media and Sports'},{ slug: 'real-estate',page_name: 'sectors',value: 'Real Estate'},{ slug: 'retail',page_name: 'sectors',value: 'Retail'},{ slug: 'pharma',page_name: 'sectors',value: 'Pharma'},{ slug: 'smart-cities',page_name: 'sectors',value: 'Smart Cities'},{ slug: 'logistics-and-allied-industries',page_name: 'sectors',value: 'Logistics & Allied Industries'},{ slug: 'oil-and-gas',page_name: 'sectors',value: 'Oil & Gas'},{ slug: 'ports',page_name: 'sectors',value: 'Ports'},{ slug: 'transport',page_name: 'sectors',value: 'Transport'},{ slug: 'renewable-and-cleantech',page_name: 'sectors',value: 'Renewable & Cleantech'},{ slug: 'startups',page_name: 'sectors',value: 'Startups'},{ slug: 'na',page_name: 'sectors',value: 'NA'},{ slug: 'corporate',page_name: 'practice-area',value: 'Corporate'},{ slug: 'banking-and-finance',page_name: 'practice-area',value: 'Finance'},{ slug: 'disputes',page_name: 'practice-area',value: 'Disputes'},{ slug: 'chennai',page_name: 'locations',value: 'Chennai'},{ slug: 'new-delhi',page_name: 'locations',value: 'New Delhi'},{ slug: 'gurugram',page_name: 'locations',value: 'Gurugram'},{ slug: 'mumbai',page_name: 'locations',value: 'Mumbai'},{ slug: 'ahmedabad',page_name: 'locations',value: 'Ahmedabad'},{ slug: 'bengaluru',page_name: 'locations',value: 'Bengaluru'},{ slug: 'hyderabad',page_name: 'locations',value: 'Hyderabad'},{ slug: 'gift-ifsc',page_name: 'locations',value: 'GIFT IFSC'},];
		function search(){
			$( "#lawyer_name" ).autocomplete({
				source: projects,
				open: function(event, ui) { $(".ui-menu").css("z-index", 200); },
				close: function(event, ui) { $(".ui-menu").css("z-index", 250); },
				select: function (event, ui) {
					window.location.replace("https://www.jsalaw.com/"+ui.item.page_name+"/"+ui.item.slug);
				}
			});
			$( "#lawyer_name_mobile" ).autocomplete({
			source: projects,
				open: function(event, ui) { $(".ui-menu").css("z-index", 200); },
				close: function(event, ui) { $(".ui-menu").css("z-index", 250); },
				select: function (event, ui) {
					window.location.replace("https://www.jsalaw.com/"+ui.item.page_name+"/"+ui.item.slug);
				}
			});
		}
		
		setTimeout(search,1000);
	});

	
	$(document).ready(function(){

		$("#home_header").click(function(){
			setTimeout(function() { 
				$("#lawyer_name").focus()
			}, 1000);
		});
	});
	$(document).ready(function(){
		$('[data-toggle="tooltip"]').tooltip(); 
	});
	$(document).ready(function(){
		var text = [
		'Agriculture','Automotive','Aviation','Defence','Education','Hospitality','Knowledge Based Industries','Telecommunications','Manufacturing & Consumer Products','Media and Sports','Real Estate','Retail','Pharma','Smart Cities','Logistics & Allied Industries','Oil & Gas','Ports','Transport','Renewable & Cleantech','Startups','NA','Corporate','Finance','Disputes',		];
		setInterval(function(){
			var c=Math.floor((Math.random() * 10) + 1);
			$("#lawyer_name").attr("placeholder", "Try '"+text[c]+"'");
		}, 4000);
	});
</script>
	
	<div class="container-fluid pt-5">
		<div class="col-md-10 offset-md-1 text-center">
			<h1>SECTORS</h1>
			<hr class=" red-dash"><br>
		</div>
	</div>
	<div class="container-fluid py-2">
		<div class="col-md-10 offset-md-1">
			<div class="col-md-10 offset-md-1 text-center">
				<div class="row">
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/agriculture">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/agriculture.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Agriculture									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/automotive">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/automotive.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Automotive									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/aviation">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/aviation.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Aviation									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/defence">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/defence.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Defence									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/education">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/education.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Education									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/hospitality">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/hospitality.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Hospitality									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/knowledge-based-industries">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/knowledge-based-industries.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Knowledge Based Industries									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/logistics-and-allied-industries">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/logistics-and-allied-industries.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Logistics & Allied Industries									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/manufacturing-and-consumer-products">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/manufacturing-and-consumer-products.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Manufacturing & Consumer Products									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/media-and-sports">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/media-and-sports.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Media and Sports									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/oil-and-gas">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/oil-and-gas.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Oil & Gas									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/pharma">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/pharma.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Pharma									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/ports">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/ports.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Ports									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/real-estate">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/real-estate.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Real Estate									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/renewable-and-cleantech">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/renewable-and-cleantech.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Renewable & Cleantech									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/retail">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/retail.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Retail									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/smart-cities">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/smart-cities.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Smart Cities									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/startups">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/startups.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Startups									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/telecommunications">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/telecommunications.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Telecommunications									</p>
								</div>
							</div>
						</a>
					</div>
										<div class="col-md-3 pt-md-5 p-md-4 p-2">
						<a href="/sectors/transport">
							<div class="p-2 rounded hvr-float-2 w-100 animated fadeIn">
								<img src="https://www.jsalaw.com/img/sector-icons/transport.svg" height="80">
								<div style="min-height: 2rem;">
									<p class="font-weight-light mt-2 mb-1 text-danger">
										Transport									</p>
								</div>
							</div>
						</a>
					</div>
										
				</div>
			</div>
		</div>
		<div class="col-12 pb-4">
			<p class="float-right text-dark">Last Updated on 25th January, 2019</p>
		</div>
	</div>
		<div class="container-fluid text-center p-0 m-0 text-white bg-dark py-3">
	<div class="row w-100 p-0 m-0">
		<div class="col-12 my-2">
			<a href="/privacy-policy" class="mx-2 text-white">Privacy Policy</a>
			<!--<a href="terms-of-service.php" class="mx-2 text-white">Terms of Service</a>-->
			<a href="/locations" class="mx-2 text-white">Contact Us</a>
		</div>
		<div class="col-12 my-2">
			<!--<a href="https://www.facebook.com/j.sagarassociates/" class="mx-2 text-white" target="_blank"><i class="fab fa-facebook" style="font-size: 140%"></i></a>-->
			<a href="https://www.linkedin.com/company/j-sagar-associates/" class="mx-2 text-white" target="_blank"><i class="fab fa-linkedin" style="font-size: 140%"></i></a>
		</div>
		<div class="col-12 my-2">
			<p class="small m-0">&copy; 2019 J. Sagar Associates All Rights Reserved.</p>
		</div>
	</div>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id=disclaimer_modal>
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content p-2">
			<div class="modal-header p-3 border-danger-bottom">
				<img src="https://www.jsalaw.com/img/jsa-logos/jsa-logo-navbar.png" width="200" class="d-inline">
			</div>
			<div class="modal-body p-3">
				<h3 class="my-1 mb-1">Disclaimer &amp; Confirmation</h3>
				<hr class="red-dash ml-0 mt-2">
				<p style="font-size: 16px;" class="mb-1">As per the rules of the Bar Council of India, we are not permitted to solicit work and advertise. By clicking on the “I agree” below, the user acknowledges the following:</p>
				<ul>
					<li style="font-size: 16px;" class="mb-1">there has been no advertisement, personal communication, solicitation, invitation or inducement of any sort whatsoever from us or any of our members to solicit any work through this website;</li>
					<li style="font-size: 16px;" class="mb-1">you wish to gain more information about us for your own information and use;</li>
					<li style="font-size: 16px;" class="mb-1">the information about us is provided to you on your specific request and any information obtained or materials downloaded from this website is completely at your own volition and any transmission, receipt or use of this site does not create any lawyer-client relationship; and that</li>
					<li style="font-size: 16px;" class="mb-1">we are not liable for any consequence of any action taken by you relying on the material / information provided on this website.</li>
				</ul>
				<p style="font-size: 16px;" class="mb-1">If you have any legal issues, you, in all cases, must seek independent legal advice.</p>
				<br>
				<p style="font-size: 16px;" class="mb-1">We use cookies to enhance your experience. By continuing to visit this website you agree to our use of cookies. </p>
			</div>
			<div class="py-3 text-center border-top">
				<button id="agree_disclaimer" type="button" class="btn btn-lg mx-3" data-dismiss="modal" style="font-size: 16px;">I Agree</button>
				<!--<button type="button" class="btn btn-lg mx-3" style="font-size: 16px;">I Disagree</button>-->
				
			</div>
		</div>
	</div>
</div>
<script>
	console.log("triggered");
	$("#agree_disclaimer").click(function(){
		var cname = "jsa_disclaimer_shown";
		var cvalue = 1;
		var exdays = 1;
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires="+d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	});
	$('#disclaimer_modal').modal({
		keyboard: false,
		backdrop: 'static'
	});

</script>
</body>
</html>